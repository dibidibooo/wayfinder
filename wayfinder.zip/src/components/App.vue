<div id="open-modal999" class="modal-window">
  <div>
    <a href="#" title="Close" class="modal-close"><b>X</b></a>
    <ul class="categories-list">
      <a href="#open-modal999">
      <li>            
        <div>{{ store1[0].title }}</div>
      </li>
    </a>
      <li>            
        <div>{{ store1[1].title }}</div>
      </li>
      <li>            
        <div>{{ store1[2].title }}</div>
      </li>
      <li>            
        <div>{{ store1[3].title }}</div>
      </li>
      <li>            
        <div>{{ store1[4].title }}</div>
      </li>
      <li>            
        <div>{{ store1[5].title }}</div>
      </li>
      <li>            
        <div>{{ store1[6].title }}</div>
      </li>
      <li>            
        <div>{{ store1[7].title }}</div>
      </li>
      <li>            
        <div>{{ store1[8].title }}</div>
      </li>
      <li>            
        <div>{{ store1[9].title }}</div>
      </li>
      <li>            
        <div>{{ store1[10].title }}</div>
      </li>
      <li>            
        <div>{{ store1[11].title }}</div>
      </li>
      <li>            
        <div>{{ store1[12].title }}</div>
      </li>
      <li>            
        <div>{{ store1[13].title }}</div>
      </li>
      <li>            
        <div>{{ store1[14].title }}</div>
      </li>
    </ul>
        </div>
</div>

<div id="open-modal2" class="modal-window">
  <div>
    <a href="#" title="Close" class="modal-close"><b>X</b></a>
    <ul class="categories-list">
      <li>
        <div>{{ store2[0].title }}</div>
      </li>
      <li>
        <div>{{ store2[1].title }}</div>
      </li>
      <li>
        <div>{{ store2[2].title }}</div>
      </li>
      <li>
        <div>{{ store2[3].title }}</div>
      </li>
    </ul>
  </div>
</div>

<div id="open-modal3" class="modal-window">
  <div>
    <a href="#" title="Close" class="modal-close"><b>X</b></a>
    <ul class="categories-list">
      <li>
        <div>{{ store3[0].title }}</div>
      </li>
      <li>
        <div>{{ store3[1].title }}</div>
      </li>
      <li>
        <div>{{ store3[2].title }}</div>
      </li>
      <li>
        <div>{{ store3[3].title }}</div>
      </li>
      <li>
        <div>{{ store3[4].title }}</div>
      </li>
      <li>
        <div>{{ store3[5].title }}</div>
      </li>
      <li>
        <div>{{ store3[6].title }}</div>
      </li>
    </ul>
  </div>
</div>

<div id="open-modal4" class="modal-window">
  <div>
    <a href="#" title="Close" class="modal-close"><b>X</b></a>
    <ul class="categories-list">
      <li>
        <div>{{ store4[0].title }}</div>
      </li>
      <li>
        <div>{{ store4[1].title }}</div>
      </li>
      <li>
        <div>{{ store4[2].title }}</div>
      </li>
      <li>
        <div>{{ store4[3].title }}</div>
      </li>
      <li>
        <div>{{ store4[4].title }}</div>
      </li>
      <li>
        <div>{{ store4[5].title }}</div>
      </li>
      <li>
        <div>{{ store4[6].title }}</div>
      </li>
      <li>
        <div>{{ store4[7].title }}</div>
      </li>
    </ul>
  </div>
</div>

<div id="open-modal5" class="modal-window">
  <div>
    <a href="#" title="Close" class="modal-close"><b>X</b></a>
    <ul class="categories-list">
      <li>
        <div>{{ store5[0].title }}</div>
      </li>
      <li>
        <div>{{ store5[1].title }}</div>
      </li>
      <li>
        <div>{{ store5[2].title }}</div>
      </li>
    </ul>
  </div>
</div>

<div id="open-modal6" class="modal-window">
  <div>
    <a href="#" title="Close" class="modal-close"><b>X</b></a>
    <ul class="categories-list">
      <li>
        <div>{{ store6[0].title }}</div>
      </li>
      <li>
        <div>{{ store6[1].title }}</div>
      </li>
      <li>
        <div>{{ store6[2].title }}</div>
      </li>
      <li>
        <div>{{ store6[3].title }}</div>
      </li>
      <li>
        <div>{{ store6[4].title }}</div>
      </li>
      <li>
        <div>{{ store6[5].title }}</div>
      </li>
      <li>
        <div>{{ store6[6].title }}</div>
      </li>
    </ul>
  </div>
</div>

<div id="open-modal7" class="modal-window">
  <div>
    <a href="#" title="Close" class="modal-close"><b>X</b></a>
    <ul class="categories-list">
      <li>
        <div>{{ store7[0].title }}</div>
      </li>
      <li>
        <div>{{ store7[1].title }}</div>
      </li>
      <li>
        <div>{{ store7[2].title }}</div>
      </li>
      <li>
        <div>{{ store7[3].title }}</div>
      </li>
      <li>
        <div>{{ store7[4].title }}</div>
      </li>
      <li>
        <div>{{ store7[5].title }}</div>
      </li>
      <li>
        <div>{{ store7[6].title }}</div>
      </li>
      <li>
        <div>{{ store7[7].title }}</div>
      </li>
      <li>
        <div>{{ store7[8].title }}</div>
      </li>
      <li>
        <div>{{ store7[9].title }}</div>
      </li>
      <li>
        <div>{{ store7[10].title }}</div>
      </li>
      <li>
        <div>{{ store7[11].title }}</div>
      </li>
      <li>
        <div>{{ store7[12].title }}</div>
      </li>
      <li>
        <div>{{ store7[13].title }}</div>
      </li>
      <li>
        <div>{{ store7[14].title }}</div>
      </li>
      <li>
        <div>{{ store7[15].title }}</div>
      </li>
      <li>
        <div>{{ store7[16].title }}</div>
      </li>
      <li>
        <div>{{ store7[17].title }}</div>
      </li>
      <li>
        <div>{{ store7[18].title }}</div>
      </li>
      <li>
        <div>{{ store7[19].title }}</div>
      </li>
      <li>
        <div>{{ store7[20].title }}</div>
      </li>
      <li>
        <div>{{ store7[21].title }}</div>
      </li>
      <li>
        <div>{{ store7[22].title }}</div>
      </li>
    </ul>
  </div>
</div>

<div id="open-modal8" class="modal-window">
  <div>
    <a href="#" title="Close" class="modal-close"><b>X</b></a>
    <ul class="categories-list">
      <li>
        <div>{{ store8[0].title }}</div>
      </li>
      <li>
        <div>{{ store8[1].title }}</div>
      </li>
      <li>
        <div>{{ store8[2].title }}</div>
      </li>
      <li>
        <div>{{ store8[3].title }}</div>
      </li>
      <li>
        <div>{{ store8[4].title }}</div>
      </li>
    </ul>
  </div>
</div>

<div id="open-modal9" class="modal-window">
  <div>
    <a href="#" title="Close" class="modal-close"><b>X</b></a>
    <ul class="categories-list">
      <li>
        <div>{{ store9[0].title }}</div>
      </li>
      <li>
        <div>{{ store9[1].title }}</div>
      </li>
      <li>
        <div>{{ store9[2].title }}</div>
      </li>
    </ul>
  </div>
</div>

<div id="open-modal10" class="modal-window">
  <div>
    <a href="#" title="Close" class="modal-close"><b>X</b></a>
    <ul class="categories-list">
      <li>
        <div>{{ store10[0].title }}</div>
      </li>
      <li>
        <div>{{ store10[1].title }}</div>
      </li>
    </ul>
  </div>
</div>

<div id="open-modal11" class="modal-window">
  <div>
    <a href="#" title="Close" class="modal-close"><b>X</b></a>
    <ul class="categories-list">
      <li>
        <div>{{ store11[0].title }}</div>
      </li>
      <li>
        <div>{{ store11[1].title }}</div>
      </li>
      <li>
        <div>{{ store11[2].title }}</div>
      </li>
      <li>
        <div>{{ store11[3].title }}</div>
      </li>
      <li>
        <div>{{ store11[4].title }}</div>
      </li>
      <li>
        <div>{{ store11[5].title }}</div>
      </li>
      <li>
        <div>{{ store11[6].title }}</div>
      </li>
    </ul>
  </div>
</div>

<div id="open-modal12" class="modal-window">
  <div>
    <a href="#" title="Close" class="modal-close"><b>X</b></a>
    <ul class="categories-list">
      <li>
        <div>{{ store12[0].title }}</div>
      </li>
      <li>
        <div>{{ store12[1].title }}</div>
      </li>
    </ul>
  </div>
</div>



border-style: ridge;
border-width: 5px;