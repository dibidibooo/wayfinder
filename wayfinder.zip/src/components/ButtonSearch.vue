<template>
  <div>
    <div class="navbar-wrapper">
      <div class="navbar-big navbar-content">
        <div class="navbar-big-wrapper modules-quotes-bg">
          <a class="modules-private-logo">
            <div class="modules-private-name">Abu Dhabi Plaza</div>
          </a>
          <div class="modules-links-wrapper modules-big-links">
            <div
              class="modules-link-wrapper"
              id="#"
              style="position: absolute; margin-right: 90em"
            >
              <a data-mdb-toggle="modal" data-mdb-target="#modaltab">
                <div class="modules-link-content">
                  <img
                    src="images/Category/search.png"
                    width="160"
                    height="80"
                    alt="lorem"
                  />
                </div>
                <div class="modules-link-text"></div>
              </a>
            </div>
            <div class="modules-link-wrapper" id="#">
              <a href="#">
                <div class="modules-link-content">
                  <img
                    src="images/Category/info.png"
                    width="65"
                    height="65"
                    alt="lorem"
                  />
                  <div class="modules-link-text">ИНФОРМАЦИЯ</div>
                </div>
              </a>
            </div>
            <div class="modules-link-wrapper" id="#">
              <a href="#">
                <div class="modules-link-content">
                  <img
                    src="images/Category/foodcourt.png"
                    width="65"
                    height="65"
                    alt="lorem"
                  />
                  <div class="modules-link-text">ФУДКОРТ</div>
                </div>
              </a>
            </div>
            <div class="modules-link-wrapper" id="#">
              <a href="#">
                <div class="modules-link-content">
                  <img
                    src="images/Category/atm.png"
                    width="65"
                    height="65"
                    alt="lorem"
                  />
                  <div class="modules-link-text">БАНКОМАТЫ</div>
                </div>
              </a>
            </div>
            <div class="modules-link-wrapper" id="#">
              <a href="#">
                <div class="modules-link-content">
                  <img
                    src="images/Category/toilet.png"
                    width="65"
                    height="65"
                    alt="lorem"
                  />
                  <div class="modules-link-text">ТУАЛЕТЫ</div>
                </div>
              </a>
            </div>
            <div class="modules-link-wrapper" id="#">
              <a href="#">
                <div class="modules-link-content">
                  <img
                    src="images/Category/administrator.png"
                    width="65"
                    height="65"
                    alt="lorem"
                  />
                  <div class="modules-link-text">РЕСЕПШН</div>
                </div>
              </a>
            </div>
            <div class="modules-link-wrapper" id="#">
              <a href="#">
                <div class="modules-link-content">
                  <img
                    src="images/Category/wardrobe.png"
                    width="65"
                    height="65"
                    alt="lorem"
                  />
                  <div class="modules-link-text">ГАРДЕРОБ</div>
                </div>
              </a>
            </div>
            <div class="modules-link-wrapper" id="#">
              <a href="#">
                <div class="modules-link-content">
                  <img
                    src="images/Category/elevator.png"
                    width="65"
                    height="65"
                    alt="lorem"
                  />
                  <div class="modules-link-text">ЛИФТ</div>
                </div>
              </a>
            </div>
            <div class="modules-link-wrapper" id="#">
              <a href="#">
                <div class="modules-link-content">
                  <img
                    src="images/Category/stairs.png"
                    width="65"
                    height="65"
                    alt="lorem"
                  />
                  <div class="modules-link-text">ЛЕСТНИЦА</div>
                </div>
              </a>
            </div>
            <div class="modules-link-wrapper" id="#">
              <a href="#">
                <div class="modules-link-content">
                  <img
                    src="images/Category/escalator.png"
                    width="65"
                    height="65"
                    alt="lorem"
                  />
                  <div class="modules-link-text">ЭСКАЛАТОР</div>
                </div>
              </a>
            </div>
            <div class="modules-link-wrapper" id="#">
              <a href="#">
                <div class="modules-link-content">
                  <img
                    src="images/Category/parking_car.png"
                    width="65"
                    height="65"
                    alt="lorem"
                  />
                  <div class="modules-link-text">ПАРКИНГ</div>
                </div>
              </a>
            </div>
            <div class="modules-link-wrapper" id="#">
              <a href="#">
                <div class="modules-link-content">
                  <img
                    src="images/Category/parking_bycicle.png"
                    width="65"
                    height="65"
                    alt="lorem"
                  />
                  <div class="modules-link-text">ВЕЛОПАРКОВКА</div>
                </div>
              </a>
            </div>
            <div class="modules-link-wrapper" id="#">
              <a href="#">
                <div class="modules-link-content">
                  <img
                    src="images/Category/parkomat.png"
                    width="65"
                    height="65"
                    alt="lorem"
                  />
                  <div class="modules-link-text">ПАРКОМАТ</div>
                </div>
              </a>
            </div>
            <div class="modules-link-wrapper" id="#">
              <a href="#">
                <div class="modules-link-content">
                  <img
                    src="images/Category/babyroom.png"
                    width="65"
                    height="65"
                    alt="lorem"
                  />
                  <div class="modules-link-text">КОМНАТА МАТЕРИ</div>
                </div>
              </a>
            </div>
            <div class="modules-link-wrapper" id="#">
              <a href="#">
                <div class="modules-link-content">
                  <img
                    src="images/Category/medcenter.png"
                    width="65"
                    height="65"
                    alt="lorem"
                  />
                  <div class="modules-link-text">МЕД. ЦЕНТР</div>
                </div>
              </a>
            </div>
            <div class="modules-link-wrapper" id="#">
              <a href="#">
                <div class="modules-link-content">
                  <img
                    src="images/Category/emergency.png"
                    width="65"
                    height="65"
                    alt="lorem"
                  />
                  <div class="modules-link-text">АВАРИЙНЫЙ ВЫХОД</div>
                </div>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal -->
    <div
      class="modal bottom fade"
      id="modaltab"
      tabindex="-1"
      aria-labelledby="exampleModalLabel"
      aria-hidden="true"
      data-mdb-backdrop="static"
      data-mdb-keyboard="true"
    >
      <div
        class="
          modal-dialog modal-xl modal-frame modal-bottom modal-dialog-centered
        "
      >
        <div class="modal-content modalminheight">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">
              <b>Выберите категорию</b>
            </h5>
            <button
              type="button"
              class="btn-close"
              data-mdb-dismiss="modal"
              aria-label="Close"
            ></button>
          </div>
          <div class="modal-body">
            <ul class="nav nav-tabs mb-3" id="myTab0" role="tablist">
              <li class="nav-item" role="presentation">
                <button
                  class="nav-link active"
                  id="tab1"
                  data-mdb-toggle="tab"
                  data-mdb-target="#tab12"
                  type="button"
                  role="tab"
                  aria-controls="tab13"
                  aria-selected="true"
                >
                <i class="fas fa-tshirt"></i>
                  {{ category_name1 }}
                </button>
              </li>
              <li class="nav-item" role="presentation">
                <button
                  class="nav-link"
                  id="tab21"
                  data-mdb-toggle="tab"
                  data-mdb-target="#tab22"
                  type="button"
                  role="tab"
                  aria-controls="tab21"
                  aria-selected="false"
                >
                <i class="fas fa-dice"></i>
                  {{ category_name2 }}
                </button>
              </li>
              <li class="nav-item" role="presentation">
                <button
                  class="nav-link"
                  id="tab31"
                  data-mdb-toggle="tab"
                  data-mdb-target="#tab32"
                  type="button"
                  role="tab"
                  aria-controls="tab33"
                  aria-selected="false"
                >
                <i class="fas fa-hands-helping"></i>
                  {{ category_name3 }}
                </button>
              </li>
              <li class="nav-item" role="presentation">
                <button
                  class="nav-link"
                  id="tab41"
                  data-mdb-toggle="tab"
                  data-mdb-target="#tab42"
                  type="button"
                  role="tab"
                  aria-controls="tab43"
                  aria-selected="false"
                >
                <i class="fas fa-ring"></i>
                  {{ category_name4 }}
                </button>
              </li>
              <!-- <li class="nav-item" role="presentation">
                <button
                  class="nav-link"
                  id="tab51"
                  data-mdb-toggle="tab"
                  data-mdb-target="#tab52"
                  type="button"
                  role="tab"
                  aria-controls="tab53"
                  aria-selected="false"
                >
                <i class="fas fa-shoe-prints"></i>
                  {{ category_name5 }}
                </button>
              </li> -->
              <li class="nav-item" role="presentation">
                <button
                  class="nav-link nav-custom-button"
                  id="tab61"
                  data-mdb-toggle="tab"
                  data-mdb-target="#tab62"
                  type="button"
                  role="tab"
                  aria-controls="tab63"
                  aria-selected="false"
                >
                <i class="fas fa-home"></i>
                  {{ category_name6 }}
                </button>
              </li>
              <li class="nav-item" role="presentation">
                <button
                  class="nav-link"
                  id="tab71"
                  data-mdb-toggle="tab"
                  data-mdb-target="#tab72"
                  type="button"
                  role="tab"
                  aria-controls="tab73"
                  aria-selected="false"
                >
                <i class="fas fa-coffee"></i>
                  {{ category_name7 }}
                </button>
              </li>
              <!-- <li class="nav-item" role="presentation">
                <button
                  class="nav-link"
                  id="tab81"
                  data-mdb-toggle="tab"
                  data-mdb-target="#tab82"
                  type="button"
                  role="tab"
                  aria-controls="tab83"
                  aria-selected="false"
                >
                  {{ category_name8 }}
                </button>
              </li>
              <li class="nav-item" role="presentation">
                <button
                  class="nav-link"
                  id="tab91"
                  data-mdb-toggle="tab"
                  data-mdb-target="#tab92"
                  type="button"
                  role="tab"
                  aria-controls="tab93"
                  aria-selected="false"
                >
                  {{ category_name9 }}
                </button>
              </li>
              <li class="nav-item" role="presentation">
                <button
                  class="nav-link"
                  id="tab101"
                  data-mdb-toggle="tab"
                  data-mdb-target="#tab102"
                  type="button"
                  role="tab"
                  aria-controls="tab103"
                  aria-selected="false"
                >
                  {{ category_name10 }}
                </button>
              </li>
              <li class="nav-item" role="presentation">
                <button
                  class="nav-link"
                  id="tab111"
                  data-mdb-toggle="tab"
                  data-mdb-target="#tab112"
                  type="button"
                  role="tab"
                  aria-controls="tab113"
                  aria-selected="false"
                >
                  {{ category_name11 }}
                </button>
              </li>
              <li class="nav-item" role="presentation">
                <button
                  class="nav-link"
                  id="tab121"
                  data-mdb-toggle="tab"
                  data-mdb-target="#tab122"
                  type="button"
                  role="tab"
                  aria-controls="tab123"
                  aria-selected="false"
                >
                  {{ category_name12 }}
                </button>
              </li> -->
            </ul>

            <div class="tab-content" id="myTabContent0">
              <div
                class="tab-pane fade show active"
                id="tab12"
                role="tabpanel"
                aria-labelledby="tab11"
              >
                <div class="row">
                  <div class="col-xl-3 col-lg-6 mb-3">
                    <a data-mdb-toggle="modal" data-mdb-target="#exampleModal11">
                      <div class="card">
                        <div class="card-body">
                          <div class="d-flex align-items-center">
                            <img
                              src="../assets/logo.png"
                              alt=""
                              style="width: 45px; height: 45px"
                              class="rounded-circle"
                            />
                            <div class="ms-3">
                              <p class="fw-bold mb-1">{{ store1[0].title }}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </a>
                  </div>
                  <div class="col-xl-3 col-lg-6 mb-3">
                    <a data-mdb-toggle="modal" data-mdb-target="#exampleModal12">
                      <div class="card">
                        <div class="card-body">
                          <div class="d-flex align-items-center">
                            <img
                              src="../assets/logo.png"
                              alt=""
                              style="width: 45px; height: 45px"
                              class="rounded-circle"
                            />
                            <div class="ms-3">
                              <p class="fw-bold mb-1">{{ store1[1].title }}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </a>
                  </div>
                  <div class="col-xl-3 col-lg-6 mb-3">
                    <a data-mdb-toggle="modal" data-mdb-target="#exampleModal13">
                      <div class="card">
                        <div class="card-body">
                          <div class="d-flex align-items-center">
                            <img
                              src="../assets/logo.png"
                              alt=""
                              style="width: 45px; height: 45px"
                              class="rounded-circle"
                            />
                            <div class="ms-3">
                              <p class="fw-bold mb-1">{{ store1[2].title }}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </a>
                  </div>
                  <div class="col-xl-3 col-lg-6 mb-3">
                    <a data-mdb-toggle="modal" data-mdb-target="#exampleModal14">
                      <div class="card">
                        <div class="card-body">
                          <div class="d-flex align-items-center">
                            <img
                              src="../assets/logo.png"
                              alt=""
                              style="width: 45px; height: 45px"
                              class="rounded-circle"
                            />
                            <div class="ms-3">
                              <p class="fw-bold mb-1">{{ store1[3].title }}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </a>
                  </div>
                  <div class="col-xl-3 col-lg-6 mb-3">
                    <a data-mdb-toggle="modal" data-mdb-target="#exampleModal15">
                      <div class="card">
                        <div class="card-body">
                          <div class="d-flex align-items-center">
                            <img
                              src="../assets/logo.png"
                              alt=""
                              style="width: 45px; height: 45px"
                              class="rounded-circle"
                            />
                            <div class="ms-3">
                              <p class="fw-bold mb-1">{{ store1[4].title }}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </a>
                  </div>
                </div>
              </div>
              <div
                class="tab-pane fade"
                id="tab22"
                role="tabpanel"
                aria-labelledby="tab21"
              >
                <div class="row">
                  <div class="col-xl-3 col-lg-6 mb-3">
                    <a data-mdb-toggle="modal" data-mdb-target="#exampleModal21">
                      <div class="card">
                        <div class="card-body">
                          <div class="d-flex align-items-center">
                            <img
                              src="../assets/logo.png"
                              alt=""
                              style="width: 45px; height: 45px"
                              class="rounded-circle"
                            />
                            <div class="ms-3">
                              <p class="fw-bold mb-1">{{ store2[0].title }}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </a>
                  </div>
                  <div class="col-xl-3 col-lg-6 mb-3">
                    <a data-mdb-toggle="modal" data-mdb-target="#exampleModal22">
                      <div class="card">
                        <div class="card-body">
                          <div class="d-flex align-items-center">
                            <img
                              src="../assets/logo.png"
                              alt=""
                              style="width: 45px; height: 45px"
                              class="rounded-circle"
                            />
                            <div class="ms-3">
                              <p class="fw-bold mb-1">{{ store2[1].title }}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </a>
                  </div>
                  <div class="col-xl-3 col-lg-6 mb-3">
                    <a data-mdb-toggle="modal" data-mdb-target="#exampleModal23">
                      <div class="card">
                        <div class="card-body">
                          <div class="d-flex align-items-center">
                            <img
                              src="../assets/logo.png"
                              alt=""
                              style="width: 45px; height: 45px"
                              class="rounded-circle"
                            />
                            <div class="ms-3">
                              <p class="fw-bold mb-1">{{ store2[2].title }}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </a>
                  </div>
                  <div class="col-xl-3 col-lg-6 mb-3">
                    <a data-mdb-toggle="modal" data-mdb-target="#exampleModal24">
                      <div class="card">
                        <div class="card-body">
                          <div class="d-flex align-items-center">
                            <img
                              src="../assets/logo.png"
                              alt=""
                              style="width: 45px; height: 45px"
                              class="rounded-circle"
                            />
                            <div class="ms-3">
                              <p class="fw-bold mb-1">{{ store2[3].title }}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </a>
                  </div>
                </div>
              </div>
              <div
                class="tab-pane fade"
                id="tab32"
                role="tabpanel"
                aria-labelledby="tab31"
              >
                <div class="row">
                  <div class="col-xl-3 col-lg-6 mb-3">
                    <a data-mdb-toggle="modal" data-mdb-target="#exampleModal31">
                      <div class="card">
                        <div class="card-body">
                          <div class="d-flex align-items-center">
                            <img
                              src="../assets/logo.png"
                              alt=""
                              style="width: 45px; height: 45px"
                              class="rounded-circle"
                            />
                            <div class="ms-3">
                              <p class="fw-bold mb-1">{{ store3[0].title }}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </a>
                  </div>
                  <div class="col-xl-3 col-lg-6 mb-3">
                    <a data-mdb-toggle="modal" data-mdb-target="#exampleModal32">
                      <div class="card">
                        <div class="card-body">
                          <div class="d-flex align-items-center">
                            <img
                              src="../assets/logo.png"
                              alt=""
                              style="width: 45px; height: 45px"
                              class="rounded-circle"
                            />
                            <div class="ms-3">
                              <p class="fw-bold mb-1">{{ store3[1].title }}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </a>
                  </div>
                  <div class="col-xl-3 col-lg-6 mb-3">
                    <a data-mdb-toggle="modal" data-mdb-target="#exampleModal33">
                      <div class="card">
                        <div class="card-body">
                          <div class="d-flex align-items-center">
                            <img
                              src="../assets/logo.png"
                              alt=""
                              style="width: 45px; height: 45px"
                              class="rounded-circle"
                            />
                            <div class="ms-3">
                              <p class="fw-bold mb-1">{{ store3[2].title }}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </a>
                  </div>
                  <div class="col-xl-3 col-lg-6 mb-3">
                    <a data-mdb-toggle="modal" data-mdb-target="#exampleModal34">
                      <div class="card">
                        <div class="card-body">
                          <div class="d-flex align-items-center">
                            <img
                              src="../assets/logo.png"
                              alt=""
                              style="width: 45px; height: 45px"
                              class="rounded-circle"
                            />
                            <div class="ms-3">
                              <p class="fw-bold mb-1">{{ store3[3].title }}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </a>
                  </div>
                  <div class="col-xl-3 col-lg-6 mb-3">
                    <a data-mdb-toggle="modal" data-mdb-target="#exampleModal35">
                      <div class="card">
                        <div class="card-body">
                          <div class="d-flex align-items-center">
                            <img
                              src="../assets/logo.png"
                              alt=""
                              style="width: 45px; height: 45px"
                              class="rounded-circle"
                            />
                            <div class="ms-3">
                              <p class="fw-bold mb-1">{{ store3[4].title }}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </a>
                  </div>
                </div>
              </div>
              <div
                class="tab-pane fade"
                id="tab42"
                role="tabpanel"
                aria-labelledby="tab41"
              >
                <div class="row">
                  <div class="col-xl-3 col-lg-6 mb-3">
                    <a data-mdb-toggle="modal" data-mdb-target="#exampleModal41">
                      <div class="card">
                        <div class="card-body">
                          <div class="d-flex align-items-center">
                            <img
                              src="../assets/logo.png"
                              alt=""
                              style="width: 45px; height: 45px"
                              class="rounded-circle"
                            />
                            <div class="ms-3">
                              <p class="fw-bold mb-1">{{ store4[0].title }}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </a>
                  </div>
                  <div class="col-xl-3 col-lg-6 mb-3">
                    <a data-mdb-toggle="modal" data-mdb-target="#exampleModal42">
                      <div class="card">
                        <div class="card-body">
                          <div class="d-flex align-items-center">
                            <img
                              src="../assets/logo.png"
                              alt=""
                              style="width: 45px; height: 45px"
                              class="rounded-circle"
                            />
                            <div class="ms-3">
                              <p class="fw-bold mb-1">{{ store4[1].title }}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </a>
                  </div>
                  <div class="col-xl-3 col-lg-6 mb-3">
                    <a data-mdb-toggle="modal" data-mdb-target="#exampleModal43">
                      <div class="card">
                        <div class="card-body">
                          <div class="d-flex align-items-center">
                            <img
                              src="../assets/logo.png"
                              alt=""
                              style="width: 45px; height: 45px"
                              class="rounded-circle"
                            />
                            <div class="ms-3">
                              <p class="fw-bold mb-1">{{ store4[2].title }}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </a>
                  </div>
                  <div class="col-xl-3 col-lg-6 mb-3">
                    <a data-mdb-toggle="modal" data-mdb-target="#exampleModal44">
                      <div class="card">
                        <div class="card-body">
                          <div class="d-flex align-items-center">
                            <img
                              src="../assets/logo.png"
                              alt=""
                              style="width: 45px; height: 45px"
                              class="rounded-circle"
                            />
                            <div class="ms-3">
                              <p class="fw-bold mb-1">{{ store4[3].title }}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </a>
                  </div>
                  <div class="col-xl-3 col-lg-6 mb-3">
                    <a data-mdb-toggle="modal" data-mdb-target="#exampleModal45">
                      <div class="card">
                        <div class="card-body">
                          <div class="d-flex align-items-center">
                            <img
                              src="../assets/logo.png"
                              alt=""
                              style="width: 45px; height: 45px"
                              class="rounded-circle"
                            />
                            <div class="ms-3">
                              <p class="fw-bold mb-1">{{ store4[4].title }}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </a>
                  </div>
                </div>
              </div>
              <div
                class="tab-pane fade"
                id="tab52"
                role="tabpanel"
                aria-labelledby="tab41"
              >
                <div class="row">
                  <div class="col-xl-3 col-lg-6 mb-3">
                    <a data-mdb-toggle="modal" data-mdb-target="#exampleModal">
                      <div class="card">
                        <div class="card-body">
                          <div class="d-flex align-items-center">
                            <img
                              src="../assets/logo.png"
                              alt=""
                              style="width: 45px; height: 45px"
                              class="rounded-circle"
                            />
                            <div class="ms-3">
                              <p class="fw-bold mb-1">{{ store5[0].title }}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </a>
                  </div>
                  <div class="col-xl-3 col-lg-6 mb-3">
                    <a data-mdb-toggle="modal" data-mdb-target="#exampleModal">
                      <div class="card">
                        <div class="card-body">
                          <div class="d-flex align-items-center">
                            <img
                              src="../assets/logo.png"
                              alt=""
                              style="width: 45px; height: 45px"
                              class="rounded-circle"
                            />
                            <div class="ms-3">
                              <p class="fw-bold mb-1">{{ store5[1].title }}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </a>
                  </div>
                  <div class="col-xl-3 col-lg-6 mb-3">
                    <a data-mdb-toggle="modal" data-mdb-target="#exampleModal">
                      <div class="card">
                        <div class="card-body">
                          <div class="d-flex align-items-center">
                            <img
                              src="../assets/logo.png"
                              alt=""
                              style="width: 45px; height: 45px"
                              class="rounded-circle"
                            />
                            <div class="ms-3">
                              <p class="fw-bold mb-1">{{ store5[2].title }}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </a>
                  </div>
                </div>
              </div>
              <div
                class="tab-pane fade"
                id="tab62"
                role="tabpanel"
                aria-labelledby="tab61"
              >
                <div class="row">
                  <div class="col-xl-3 col-lg-6 mb-3">
                    <a data-mdb-toggle="modal" data-mdb-target="#exampleModal61">
                      <div class="card">
                        <div class="card-body">
                          <div class="d-flex align-items-center">
                            <img
                              src="../assets/logo.png"
                              alt=""
                              style="width: 45px; height: 45px"
                              class="rounded-circle"
                            />
                            <div class="ms-3">
                              <p class="fw-bold mb-1">{{ store6[0].title }}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </a>
                  </div>
                  <div class="col-xl-3 col-lg-6 mb-3">
                    <a data-mdb-toggle="modal" data-mdb-target="#exampleModal62">
                      <div class="card">
                        <div class="card-body">
                          <div class="d-flex align-items-center">
                            <img
                              src="../assets/logo.png"
                              alt=""
                              style="width: 45px; height: 45px"
                              class="rounded-circle"
                            />
                            <div class="ms-3">
                              <p class="fw-bold mb-1">{{ store6[1].title }}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </a>
                  </div>
                  <div class="col-xl-3 col-lg-6 mb-3">
                    <a data-mdb-toggle="modal" data-mdb-target="#exampleModal63">
                      <div class="card">
                        <div class="card-body">
                          <div class="d-flex align-items-center">
                            <img
                              src="../assets/logo.png"
                              alt=""
                              style="width: 45px; height: 45px"
                              class="rounded-circle"
                            />
                            <div class="ms-3">
                              <p class="fw-bold mb-1">{{ store6[2].title }}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </a>
                  </div>
                  <div class="col-xl-3 col-lg-6 mb-3">
                    <a data-mdb-toggle="modal" data-mdb-target="#exampleModal64">
                      <div class="card">
                        <div class="card-body">
                          <div class="d-flex align-items-center">
                            <img
                              src="../assets/logo.png"
                              alt=""
                              style="width: 45px; height: 45px"
                              class="rounded-circle"
                            />
                            <div class="ms-3">
                              <p class="fw-bold mb-1">{{ store6[3].title }}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </a>
                  </div>
                  <div class="col-xl-3 col-lg-6 mb-3">
                    <a data-mdb-toggle="modal" data-mdb-target="#exampleModal65">
                      <div class="card">
                        <div class="card-body">
                          <div class="d-flex align-items-center">
                            <img
                              src="../assets/logo.png"
                              alt=""
                              style="width: 45px; height: 45px"
                              class="rounded-circle"
                            />
                            <div class="ms-3">
                              <p class="fw-bold mb-1">{{ store6[4].title }}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </a>
                  </div>
                </div>
              </div>
              <div
                class="tab-pane fade"
                id="tab72"
                role="tabpanel"
                aria-labelledby="tab71"
              >
                <div class="row">
                  <div class="col-xl-3 col-lg-6 mb-3">
                    <a data-mdb-toggle="modal" data-mdb-target="#exampleModal71">
                      <div class="card">
                        <div class="card-body">
                          <div class="d-flex align-items-center">
                            <img
                              src="../assets/logo.png"
                              alt=""
                              style="width: 45px; height: 45px"
                              class="rounded-circle"
                            />
                            <div class="ms-3">
                              <p class="fw-bold mb-1">{{ store7[0].title }}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </a>
                  </div>
                  <div class="col-xl-3 col-lg-6 mb-3">
                    <a data-mdb-toggle="modal" data-mdb-target="#exampleModal72">
                      <div class="card">
                        <div class="card-body">
                          <div class="d-flex align-items-center">
                            <img
                              src="../assets/logo.png"
                              alt=""
                              style="width: 45px; height: 45px"
                              class="rounded-circle"
                            />
                            <div class="ms-3">
                              <p class="fw-bold mb-1">{{ store7[1].title }}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </a>
                  </div>
                  <div class="col-xl-3 col-lg-6 mb-3">
                    <a data-mdb-toggle="modal" data-mdb-target="#exampleModal73">
                      <div class="card">
                        <div class="card-body">
                          <div class="d-flex align-items-center">
                            <img
                              src="../assets/logo.png"
                              alt=""
                              style="width: 45px; height: 45px"
                              class="rounded-circle"
                            />
                            <div class="ms-3">
                              <p class="fw-bold mb-1">{{ store7[2].title }}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </a>
                  </div>
                  <div class="col-xl-3 col-lg-6 mb-3">
                    <a data-mdb-toggle="modal" data-mdb-target="#exampleModal74">
                      <div class="card">
                        <div class="card-body">
                          <div class="d-flex align-items-center">
                            <img
                              src="../assets/logo.png"
                              alt=""
                              style="width: 45px; height: 45px"
                              class="rounded-circle"
                            />
                            <div class="ms-3">
                              <p class="fw-bold mb-1">{{ store7[3].title }}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </a>
                  </div>
                  <div class="col-xl-3 col-lg-6 mb-3">
                    <a data-mdb-toggle="modal" data-mdb-target="#exampleModal75">
                      <div class="card">
                        <div class="card-body">
                          <div class="d-flex align-items-center">
                            <img
                              src="../assets/logo.png"
                              alt=""
                              style="width: 45px; height: 45px"
                              class="rounded-circle"
                            />
                            <div class="ms-3">
                              <p class="fw-bold mb-1">{{ store7[4].title }}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </a>
                  </div>
                </div>
              </div>
              <div
                class="tab-pane fade"
                id="tab82"
                role="tabpanel"
                aria-labelledby="tab81"
              >
                <div class="row">
                  <div class="col-xl-3 col-lg-6 mb-3">
                    <a data-mdb-toggle="modal" data-mdb-target="#exampleModal">
                      <div class="card">
                        <div class="card-body">
                          <div class="d-flex align-items-center">
                            <img
                              src="../assets/logo.png"
                              alt=""
                              style="width: 45px; height: 45px"
                              class="rounded-circle"
                            />
                            <div class="ms-3">
                              <p class="fw-bold mb-1">{{ store8[0].title }}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </a>
                  </div>
                  <div class="col-xl-3 col-lg-6 mb-3">
                    <a data-mdb-toggle="modal" data-mdb-target="#exampleModal">
                      <div class="card">
                        <div class="card-body">
                          <div class="d-flex align-items-center">
                            <img
                              src="../assets/logo.png"
                              alt=""
                              style="width: 45px; height: 45px"
                              class="rounded-circle"
                            />
                            <div class="ms-3">
                              <p class="fw-bold mb-1">{{ store8[1].title }}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </a>
                  </div>
                  <div class="col-xl-3 col-lg-6 mb-3">
                    <a data-mdb-toggle="modal" data-mdb-target="#exampleModal">
                      <div class="card">
                        <div class="card-body">
                          <div class="d-flex align-items-center">
                            <img
                              src="../assets/logo.png"
                              alt=""
                              style="width: 45px; height: 45px"
                              class="rounded-circle"
                            />
                            <div class="ms-3">
                              <p class="fw-bold mb-1">{{ store8[2].title }}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </a>
                  </div>
                  <div class="col-xl-3 col-lg-6 mb-3">
                    <a data-mdb-toggle="modal" data-mdb-target="#exampleModal">
                      <div class="card">
                        <div class="card-body">
                          <div class="d-flex align-items-center">
                            <img
                              src="../assets/logo.png"
                              alt=""
                              style="width: 45px; height: 45px"
                              class="rounded-circle"
                            />
                            <div class="ms-3">
                              <p class="fw-bold mb-1">{{ store8[3].title }}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </a>
                  </div>
                  <div class="col-xl-3 col-lg-6 mb-3">
                    <a data-mdb-toggle="modal" data-mdb-target="#exampleModal">
                      <div class="card">
                        <div class="card-body">
                          <div class="d-flex align-items-center">
                            <img
                              src="../assets/logo.png"
                              alt=""
                              style="width: 45px; height: 45px"
                              class="rounded-circle"
                            />
                            <div class="ms-3">
                              <p class="fw-bold mb-1">{{ store8[4].title }}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </a>
                  </div>
                </div>
              </div>
              <div
                class="tab-pane fade"
                id="tab92"
                role="tabpanel"
                aria-labelledby="tab91"
              >
                <div class="row">
                  <div class="col-xl-3 col-lg-6 mb-3">
                    <a data-mdb-toggle="modal" data-mdb-target="#exampleModal">
                      <div class="card">
                        <div class="card-body">
                          <div class="d-flex align-items-center">
                            <img
                              src="../assets/logo.png"
                              alt=""
                              style="width: 45px; height: 45px"
                              class="rounded-circle"
                            />
                            <div class="ms-3">
                              <p class="fw-bold mb-1">{{ store9[0].title }}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </a>
                  </div>
                  <div class="col-xl-3 col-lg-6 mb-3">
                    <a data-mdb-toggle="modal" data-mdb-target="#exampleModal">
                      <div class="card">
                        <div class="card-body">
                          <div class="d-flex align-items-center">
                            <img
                              src="../assets/logo.png"
                              alt=""
                              style="width: 45px; height: 45px"
                              class="rounded-circle"
                            />
                            <div class="ms-3">
                              <p class="fw-bold mb-1">{{ store9[1].title }}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </a>
                  </div>
                </div>
              </div>
              <div
                class="tab-pane fade"
                id="tab102"
                role="tabpanel"
                aria-labelledby="tab101"
              >
                <div class="row">
                  <div class="col-xl-3 col-lg-6 mb-3">
                    <a data-mdb-toggle="modal" data-mdb-target="#exampleModal">
                      <div class="card">
                        <div class="card-body">
                          <div class="d-flex align-items-center">
                            <img
                              src="../assets/logo.png"
                              alt=""
                              style="width: 45px; height: 45px"
                              class="rounded-circle"
                            />
                            <div class="ms-3">
                              <p class="fw-bold mb-1">{{ store10[0].title }}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </a>
                  </div>
                  <div class="col-xl-3 col-lg-6 mb-3">
                    <a data-mdb-toggle="modal" data-mdb-target="#exampleModal">
                      <div class="card">
                        <div class="card-body">
                          <div class="d-flex align-items-center">
                            <img
                              src="../assets/logo.png"
                              alt=""
                              style="width: 45px; height: 45px"
                              class="rounded-circle"
                            />
                            <div class="ms-3">
                              <p class="fw-bold mb-1">{{ store10[1].title }}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </a>
                  </div>
                </div>
              </div>
              <div
                class="tab-pane fade"
                id="tab112"
                role="tabpanel"
                aria-labelledby="tab111"
              >
                <div class="row">
                  <div class="col-xl-3 col-lg-6 mb-3">
                    <a data-mdb-toggle="modal" data-mdb-target="#exampleModal">
                      <div class="card">
                        <div class="card-body">
                          <div class="d-flex align-items-center">
                            <img
                              src="../assets/logo.png"
                              alt=""
                              style="width: 45px; height: 45px"
                              class="rounded-circle"
                            />
                            <div class="ms-3">
                              <p class="fw-bold mb-1">{{ store11[0].title }}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </a>
                  </div>
                  <div class="col-xl-3 col-lg-6 mb-3">
                    <a data-mdb-toggle="modal" data-mdb-target="#exampleModal">
                      <div class="card">
                        <div class="card-body">
                          <div class="d-flex align-items-center">
                            <img
                              src="../assets/logo.png"
                              alt=""
                              style="width: 45px; height: 45px"
                              class="rounded-circle"
                            />
                            <div class="ms-3">
                              <p class="fw-bold mb-1">{{ store11[1].title }}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </a>
                  </div>
                </div>
              </div>
              <div
                class="tab-pane fade"
                id="tab122"
                role="tabpanel"
                aria-labelledby="tab121"
              >
                <div class="row">
                  <div class="col-xl-3 col-lg-6 mb-3">
                    <a data-mdb-toggle="modal" data-mdb-target="#exampleModal">
                      <div class="card">
                        <div class="card-body">
                          <div class="d-flex align-items-center">
                            <img
                              src="../assets/logo.png"
                              alt=""
                              style="width: 45px; height: 45px"
                              class="rounded-circle"
                            />
                            <div class="ms-3">
                              <p class="fw-bold mb-1">{{ store12[0].title }}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </a>
                  </div>
                  <div class="col-xl-3 col-lg-6 mb-3">
                    <a data-mdb-toggle="modal" data-mdb-target="#exampleModal">
                      <div class="card">
                        <div class="card-body">
                          <div class="d-flex align-items-center">
                            <img
                              src="../assets/logo.png"
                              alt=""
                              style="width: 45px; height: 45px"
                              class="rounded-circle"
                            />
                            <div class="ms-3">
                              <p class="fw-bold mb-1">{{ store12[1].title }}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button
              type="button"
              class="btn btn-secondary"
              data-mdb-dismiss="modal"
            >
              Закрыть
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>


<script>
import axios from "axios";
export default {
  data: () => ({
    category_name1: null,
    category_name2: null,
    category_name3: null,
    category_name4: null,
    category_name5: null,
    category_name6: null,
    category_name7: null,
    category_name8: null,
    category_name9: null,
    category_name10: null,
    category_name11: null,
    category_name12: null,
    category1: null,
    category2: null,
    category3: null,
    category4: null,
    category5: null,
    category6: null,
    category7: null,
    category8: null,
    category9: null,
    category10: null,
    category11: null,
    category12: null,
    store1: [],
    store2: [],
    store3: [],
    store4: [],
    store5: [],
    store6: [],
    store7: [],
    store8: [],
    store9: [],
    store10: [],
    store11: [],
    store12: [],
    errors: [],
  }),

  mounted() {
    this.getStores();
  },
  methods: {
    add_row_by_name(name = "0") {
      this.unselect_objects(this.path_lsit[name].objects);
      this.road_floors = [];

      this.create_floor_rows(name);

      if (this.road_floors.length == 1) {
        this.change_floor(this.road_floors[0]);
      } else {
        this.change_floor(this.selected_floor);
      }
      // this.create_row(this.path_lsit[name].road);
      this.select_objects(this.path_lsit[name].objects);
    },

    getStores() {
      axios
        .get("http://Localhost:8100/api/categories")
        .then((response) => {
          this.category_name1 = response.data[0].title;
          this.category_name2 = response.data[1].title;
          this.category_name3 = response.data[2].title;
          this.category_name4 = response.data[3].title;
          this.category_name5 = response.data[4].title;
          this.category_name6 = response.data[5].title;
          this.category_name7 = response.data[6].title;
          this.category_name8 = response.data[7].title;
          this.category_name9 = response.data[8].title;
          this.category_name10 = response.data[9].title;
          this.category_name11 = response.data[10].title;
          this.category_name12 = response.data[11].title;

          this.category1 = response.data[0].stores;
          for (let i in this.category1) {
            this.store1.push(this.category1[i]);
            // console.log(this.store)
          }
          console.log("Category 1", this.category1);

          this.category2 = response.data[1].stores;
          for (let i in this.category2) {
            this.store2.push(this.category2[i]);
            // console.log(this.store)
          }
          console.log("Category 2", this.category2);

          this.category3 = response.data[2].stores;
          for (let i in this.category3) {
            this.store3.push(this.category3[i]);
            // console.log(this.store)
          }
          console.log("Category 3", this.category3);

          this.category4 = response.data[3].stores;
          for (let i in this.category4) {
            this.store4.push(this.category4[i]);
            // console.log(this.store)
          }
          console.log("Category 4", this.category4);

          this.category5 = response.data[4].stores;
          for (let i in this.category5) {
            this.store5.push(this.category5[i]);
            // console.log(this.store)
          }
          console.log("Category 5", this.category5);

          this.category6 = response.data[5].stores;
          for (let i in this.category6) {
            this.store6.push(this.category6[i]);
            // console.log(this.store)
          }
          console.log("Category 6", this.category6);

          this.category7 = response.data[6].stores;
          for (let i in this.category7) {
            this.store7.push(this.category7[i]);
            // console.log(this.store)
          }
          console.log("Category 7", this.category7);

          this.category8 = response.data[7].stores;
          for (let i in this.category8) {
            this.store8.push(this.category8[i]);
            // console.log(this.store)
          }
          console.log("Category 8", this.category8);

          this.category9 = response.data[8].stores;
          for (let i in this.category9) {
            this.store9.push(this.category9[i]);
            // console.log(this.store)
          }
          console.log("Category 9", this.category9);

          this.category10 = response.data[9].stores;
          for (let i in this.category10) {
            this.store10.push(this.category10[i]);
            // console.log(this.store)
          }
          console.log("Category 10", this.category10);

          this.category11 = response.data[10].stores;
          for (let i in this.category11) {
            this.store11.push(this.category11[i]);
            // console.log(this.store)
          }
          console.log("Category 11", this.category11);

          this.category12 = response.data[11].stores;
          for (let i in this.category12) {
            this.store12.push(this.category12[i]);
            // console.log(this.store)
          }
          console.log("Category 12", this.category12);
        })
        .catch((e) => {
          this.errors.push(e);
        });
    },
  },
};
</script>


<style scoped>
.nav-link.active {
  color: #fff !important;
  background: #e65398 !important;
  border-radius: 8px !important;
  box-shadow: inset 2px 2px 2px 0px rgba(255, 255, 255, 0.5),
    7px 7px 20px 0px rgba(0, 0, 0, 0.1), 4px 4px 5px 0px rgba(0, 0, 0, 0.1);
  border-color: #f18eb4 !important;
  outline: none;
}

.card:hover {
  background-color: #f18eb4;
}
.modalminheight {
  /* background: #1d1d1d;
  border-style: ridge;
  border-width: 5px; */
  min-height: 30em;
}
/* _________________________________ NAVBAR _________________________________ */
.navbar-wrapper {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
  margin: 0;
  padding: 0;
  position: absolute;
}

.navbar-content {
  width: 100%;
}

@media (min-width: 600px) {
  .navbar-big {
    display: none;
  }
}

@media (min-width: 900px) {
  .navbar-big {
    display: block;
  }
}

.navbar-big-wrapper {
  -webkit-transition: background 0.5s linear;
  transition: background 0.5s linear;
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-pack: center;
  -ms-flex-pack: center;
  justify-content: center;
  -webkit-box-align: center;
  -ms-flex-align: center;
  align-items: center;
  width: 100%;
  color: #fff;
  padding: 0px;
}

.modules-quotes-bg {
  background: #f1f1f1;
  filter: drop-shadow(0 0 16px #787878);
}

.modules-private-logo {
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-orient: vertical;
  -webkit-box-direction: normal;
  -ms-flex-direction: column;
  flex-direction: column;
  -webkit-box-align: end;
  -ms-flex-align: end;
  align-items: flex-end;
  margin-right: auto;
  line-height: 1;
}

a {
  text-decoration: none;
}

a {
  color: inherit;
  font-weight: 700;
  font-family: inherit;
}

.modules-private-name {
  font-family: Impact, Charcoal, sans-serif;
  font-weight: 100;
  font-size: 32px;
  color: #b91e67;
}

.modules-big-links {
  width: 100%;
  /* margin-right: 50em; */
}

.modules-big-contact,
.modules-big-links {
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-pack: center;
  -ms-flex-pack: center;
  justify-content: center;
  -webkit-box-align: center;
  -ms-flex-align: center;
  align-items: center;
}

.modules-links-wrapper {
  position: relative;
  /* border-right: 1px solid hsla(0, 0%, 100%, 0.4); */
}

.modules-link-wrapper {
  cursor: pointer;
}

@media (min-width: 600px) {
  .modules-link-wrapper {
    width: auto;
  }
}

@media (min-width: 900px) {
  .modules-link-wrapper {
    width: 85px;
  }
}

.modules-link-content {
  color: #fff;
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-orient: vertical;
  -webkit-box-direction: normal;
  -ms-flex-direction: column;
  flex-direction: column;
  -webkit-box-align: center;
  -ms-flex-align: center;
  align-items: center;
  -webkit-box-pack: center;
  -ms-flex-pack: center;
  justify-content: center;
  padding: 1em;
}

@media (min-width: 600px) {
  .modules-link-content {
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -ms-flex-direction: row;
    flex-direction: row;
    -webkit-box-pack: start;
    -ms-flex-pack: start;
    justify-content: flex-start;
    /* border-bottom: 1px solid hsla(0, 0%, 100%, 0.4); */
  }
}

@media (min-width: 900px) {
  .modules-link-content {
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -ms-flex-direction: column;
    flex-direction: column;
    /* border-left: 1px solid hsla(0, 0%, 100%, 0.4); */
    border-bottom: none;
  }
}

@media (min-width: 600px) {
  .modules-link-text {
    font-family: "Franklin Gothic Medium", "Arial Narrow", Arial, sans-serif;
    font-weight: 700;
    font-size: 28px;
    padding: 0 1em;
  }
}

@media (min-width: 900px) {
  .modules-link-text {
    color: #000000;
    font-size: 10px;
    padding: 1em 0 0;
  }
}

.modules-big-contact,
.modules-big-links {
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-pack: center;
  -ms-flex-pack: center;
  justify-content: center;
  -webkit-box-align: center;
  -ms-flex-align: center;
  align-items: center;
}

/* _________________________________ END OF THE NAVBAR _________________________________ */

/* _________________________________ CUSTOM STYLE _________________________________ */

/* _________________________________ END OF THE CUSTOM STYLE _________________________________ */
</style>