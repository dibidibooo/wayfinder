<template>
  <div class="footer"></div>
</template>


<style>
.footer {
  background: #f1f1f1df;
  filter: drop-shadow(0 0 16px #787878);
  margin-top: 62em;
  margin-left: 52.9em;
  width: 350px;
  height: 170px;
  border-radius: 50px 50px 0 0;
  position: fixed;
  z-index: 99;
}

.bubblybutton {
  position: absolute;
  width: 130px;
  height: 100px;
  background: #b91e67;
  border-radius: 10px;
  border-color: #ffffff;
  color: rgba(255, 255, 255, 0.8);
  font-family: Arial;
  font-size: 24px;
  font-weight: 700;
  margin-top: 43em;
  z-index: 100;
  box-shadow: inset 2px 2px 2px 0px rgba(255, 255, 255, 0.5),
    7px 7px 20px 0px rgba(0, 0, 0, 0.1), 4px 4px 5px 0px rgba(0, 0, 0, 0.1);
  outline: none;
}
</style>

