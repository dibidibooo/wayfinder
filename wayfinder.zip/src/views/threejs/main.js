




export default{
  test_function: ()=>{
    console.log(">>> hello my frend");
  }
}
